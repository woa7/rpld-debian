/*************************************************
*     rpld - an IBM style RIPL server            *
*************************************************/

/* Copyright (c) 2000, James McKenzie.
 *                      All rights reserved
 *
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENCE file which can be found at the top level of
 * the rpld distribution.
 *
 * IBM is a trademark of IBM corp.
 *
 */


/*
 * $Id: nit.h,v 1.2 2000/09/26 03:44:29 root Exp $
 *
 * $Log: nit.h,v $
 * Revision 1.2  2000/09/26 03:44:29  root
 * #
 *
 * Revision 1.1  2000/09/26 02:32:16  root
 * Initial revision
 *
 *  
 */

#define NIT_MAX_NAME_LEN 1024

struct nit;

struct nit *nit_open (char *name);
int nit_recv (struct nit *n, unsigned char *buf, int len, unsigned char *from,
              struct timeval *tv);
int nit_send (struct nit *n, unsigned char *frame, int len,
              unsigned char *to);
unsigned char *nit_mac (struct nit *n);
int nit_multicast (struct nit *n, unsigned char *mcaddr);
void nit_close (struct nit *n);
