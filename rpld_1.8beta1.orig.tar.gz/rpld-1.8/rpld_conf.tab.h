#define BLOCK_START 257
#define BLOCK_END 258
#define NAME 259
#define TEXT 260
#define NUMBER 261
#define MACADDR 262
#define MACADDR_PARTIAL 263
typedef union {
		long number;
		char *name;
		char *text;
		char mac_address[6];
		struct partial_mac {
			char mac_address[6];
			int mac_len;
		} pm;
	} YYSTYPE;
extern YYSTYPE yylval;
