/*************************************************
*     rpld - an IBM style RIPL server            *
*************************************************/

/* Copyright (c) 1999,2000, James McKenzie.
 *                      All rights reserved
 * Copyright (c) 1998,2000, Christopher Lightfoot.
 *                      All rights reserved
 *
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENCE file which can be found at the top level of
 * the rpld distribution.
 *
 * IBM is a trademark of IBM corp.
 *
 */

/*
 * $Id: project.h,v 1.17 2000/09/26 01:39:17 root Exp $
 *
 * $Log: project.h,v $
 * Revision 1.17  2000/09/26 01:39:17  root
 * #
 *
 * Revision 1.16  2000/09/26 01:03:19  root
 * #
 *
 * Revision 1.15  2000/07/23 19:14:19  root
 * #
 *
 * Revision 1.14  2000/07/17 11:59:45  root
 * #
 *
 * Revision 1.13  2000/07/16 21:09:57  root
 * #
 *
 * Revision 1.12  2000/07/16 14:05:28  root
 * #
 *
 * Revision 1.11  2000/07/16 13:18:10  root
 * #
 *
 * Revision 1.1  2000/07/16 13:16:33  root
 * #
 *
 * Revision 1.10  1999/09/14 21:36:02  root
 * #
 *
 * Revision 1.9  1999/09/13 12:37:05  root
 * #
 *
 * Revision 1.8  1999/09/13 12:36:18  root
 * #
 *
 * Revision 1.7  1999/09/13 11:17:35  root
 * \#
 *
 * Revision 1.6  1999/09/13 11:05:27  root
 * \#
 *
 * Revision 1.5  1999/09/13 11:04:13  root
 * \#
 *  
 */

/* EDITME: this is the delay between transmitted packets in us */
/* you may need to edit this if your clients are slow */
/* if a client drops a packet it will typically wait 1s and then */
/* issue a retransmit request */

#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/time.h>
#include <syslog.h>
#include <fcntl.h>
#include <unistd.h>
#include <malloc.h>


extern int downloading;

#ifndef ETH_ALEN
#define ETH_ALEN 6
#endif

#define MAX_FRAME_LEN 1514

#define MY_FRAME_LEN 1500
#define MY_BLOCK_LEN 1440       /*quad word aligned */
#define MY_PACING    10000


#define CONFIG_FILE "/etc/rpld.conf"

#define NOTINRANGE(l,v,h) (((v)<(l)) || ((v)>(h)))


#include "llc.h"
#include "rpl.h"
#include "client.h"


extern int rpl_sap;
#include "prototypes.h"
