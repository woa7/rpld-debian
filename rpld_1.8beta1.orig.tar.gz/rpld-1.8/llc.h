/*************************************************
*     rpld - an IBM style RIPL server            *
*************************************************/

/*
 * llc.h:
 *
 * Copyright (c) 2000 James McKenzie <james@fishsoup.dhs.org>,
 * All rights reserved.
 *
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENCE file which can be found at the top level of
 * the rpld distribution.
 *
 * IBM is a trademark of IBM corp.
 *
 */

/*
 * $Id: llc.h,v 1.11 2000/09/26 01:41:08 root Exp $
 */

/*
 * $Log: llc.h,v $
 * Revision 1.11  2000/09/26 01:41:08  root
 * #
 *
 * Revision 1.10  2000/09/26 01:39:17  root
 * #
 *
 * Revision 1.9  2000/09/26 01:03:19  root
 * #
 *
 */

#ifndef __LLC_H__
#define __LLC_H__



#define LLCDRV \
        int (*recv)(struct llcdrv *,unsigned char *,int,unsigned char *,unsigned char *,struct timeval *); \
	int (*send)(struct llcdrv *,unsigned char *,unsigned char,unsigned char *,int); \
	unsigned char *(*mac)(struct llcdrv *); \
	int (*add_multicast)(struct llcdrv *,unsigned char *); \
	void (*close)(struct llcdrv *)

struct llcdrv
{
  LLCDRV;
};

extern struct llcdrv *llc_open (unsigned char, char *);

#endif /* __LLC_H__ */
